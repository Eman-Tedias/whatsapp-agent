from groq import Groq
import instructor

from .. import config

_raw_client = None
_instructor_client = None


def _get_clients():
  global _raw_client, _instructor_client
  if _raw_client is None:
    _raw_client = Groq(
      api_key=config.GROQ_API_KEY,
      timeout=config.REQUEST_TIMEOUT,
      max_retries=3,
    )
    _instructor_client = instructor.from_groq(_raw_client)
  return _raw_client, _instructor_client


def _extract_usage(response):
  usage = getattr(response, 'usage', None)
  if usage is None:
    return None
  return {
    'input': usage.prompt_tokens,
    'output': usage.completion_tokens,
    'total': usage.total_tokens,
  }


def run(
    model: str,
    messages: list[dict],
    output_model,
    system_prompt=None,
    effort: str = None,
    temperature: float = None,
    max_tokens: int = None,
  ):
  raw_client, instructor_client = _get_clients()
  if system_prompt:
    messages = [{'role': 'system', 'content': system_prompt}] + messages
  extra_kwargs = {'reasoning_effort': effort} if effort else {}
  if temperature is not None:
    extra_kwargs['temperature'] = temperature
  if max_tokens is not None:
    extra_kwargs['max_tokens'] = max_tokens
  if output_model:
    parsed, completion = instructor_client.chat.completions.create_with_completion(
      model=model,
      messages=messages,
      response_model=output_model,
      **extra_kwargs,
    )
    return parsed, _extract_usage(completion)
  else:
    response = raw_client.chat.completions.create(
      model=model,
      messages=messages,
      **extra_kwargs,
    )
    return response.choices[0].message.content, _extract_usage(response)
