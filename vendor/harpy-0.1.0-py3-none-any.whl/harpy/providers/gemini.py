from google import genai
from google.genai import types
import instructor

from .. import config
from ..catalog import resolve_temperature

_raw_client = None
_instructor_client = None


def _get_clients():
  global _raw_client, _instructor_client
  if _raw_client is None:
    if config.VERTEX_PROJECT:
      _raw_client = genai.Client(
        vertexai=True,
        project=config.VERTEX_PROJECT,
        location=config.VERTEX_LOCATION,
      )
    else:
      _raw_client = genai.Client(api_key=config.GEMINI_API_KEY)
    _instructor_client = instructor.from_genai(_raw_client)
  return _raw_client, _instructor_client


def _build_thinking_config(effort, reasoning_tokens, include_thoughts=None):
  # "is not None" instead of truthy -- thinking_budget=0 is a valid, documented API
  # value (explicitly disables thinking on models that allow disabling it); a truthy
  # check treated 0 as "not set" and dropped the whole thinking_config, leaving the
  # model on default behavior instead of disabling thinking as requested. A model that
  # doesn't accept budget=0 (e.g. gemini-2.5-pro) will reject it with a 400 from the
  # API itself -- a clear failure, not a silent "disabled" that didn't actually disable
  # anything.
  if effort is None and reasoning_tokens is None and include_thoughts is None:
    return None
  if effort is not None and reasoning_tokens is not None:
    raise ValueError(
      'thinking_budget (reasoning_tokens) and thinking_level (effort) are mutually '
      'exclusive on Gemini -- pick one.'
    )
  kwargs = {}
  if reasoning_tokens is not None:
    kwargs['thinking_budget'] = reasoning_tokens
  if effort is not None:
    kwargs['thinking_level'] = effort.upper()
  if include_thoughts is not None:
    kwargs['include_thoughts'] = include_thoughts
  return types.ThinkingConfig(**kwargs)


def _build_media_resolution(value):
  if not value:
    return None
  return f'MEDIA_RESOLUTION_{value.upper()}'


def _build_contents(text, images):
  if not images:
    return text
  parts = [types.Part.from_bytes(data=data, mime_type=mime) for data, mime in images]
  return [text] + parts


def _build_search_tools(search_enabled, search_urls):
  if not search_enabled:
    return None
  # google_search and url_context are combinable in the same call (the docs recommend
  # using both together when the prompt needs broad search + deep reading of a specific
  # URL) -- this used to only pick one of the two.
  tools = [types.Tool(google_search=types.GoogleSearch())]
  if search_urls:
    tools.append(types.Tool(url_context=types.UrlContext()))
  return tools


def _inject_urls(text, search_urls):
  if not search_urls:
    return text
  urls_text = '\n'.join(search_urls)
  return f'{text}\n\nReference URLs:\n{urls_text}'


def _extract_usage(response):
  usage = getattr(response, 'usage_metadata', None)
  if usage is None:
    return None
  return {
    'input': usage.prompt_token_count or 0,
    'output': usage.candidates_token_count or 0,
    'total': usage.total_token_count or 0,
  }


def run(
    model: str,
    messages: list[dict],
    output_model,
    input_images: list,
    search_enabled: bool,
    search_urls: list,
    system_prompt=None,
    effort: str = None,
    reasoning_tokens: int = None,
    temperature: float = None,
    include_thoughts: bool = None,
    media_resolution: str = None,
    top_p: float = None,
    top_k: float = None,
    candidate_count: int = None,
    seed: int = None,
    stop_sequences: list = None,
    max_tokens: int = None,
  ):
  raw_client, instructor_client = _get_clients()
  temperature = resolve_temperature(model, temperature)

  if output_model and input_images:
    # image + schema: instructor doesn't forward image Parts, call raw genai directly.
    response = raw_client.models.generate_content(
      model=model,
      contents=_build_contents(messages[-1]['content'], input_images),
      config=types.GenerateContentConfig(
        system_instruction=system_prompt,
        response_mime_type='application/json',
        response_schema=output_model,
        thinking_config=_build_thinking_config(effort, reasoning_tokens, include_thoughts),
        temperature=temperature,
        media_resolution=_build_media_resolution(media_resolution),
        top_p=top_p,
        top_k=top_k,
        candidate_count=candidate_count,
        seed=seed,
        stop_sequences=stop_sequences,
        max_output_tokens=max_tokens,
      ),
    )
    return output_model.model_validate_json(response.text), _extract_usage(response)

  if output_model:
    if search_enabled:
      raise ValueError('Combining search() with output(schema) is not supported yet (Gemini does not allow controlled generation together with search).')
    if system_prompt:
      messages = [{'role': 'system', 'content': system_prompt}] + messages
    extra = {'temperature': temperature} if temperature is not None else {}
    thinking = _build_thinking_config(effort, reasoning_tokens, include_thoughts)
    if thinking is not None:
      extra['thinking_config'] = thinking
    if top_p is not None:
      extra['top_p'] = top_p
    if top_k is not None:
      extra['top_k'] = top_k
    if candidate_count is not None:
      extra['candidate_count'] = candidate_count
    if seed is not None:
      extra['seed'] = seed
    if stop_sequences is not None:
      extra['stop_sequences'] = stop_sequences
    if max_tokens is not None:
      extra['max_output_tokens'] = max_tokens
    parsed, completion = instructor_client.chat.completions.create_with_completion(
      model=model,
      messages=messages,
      response_model=output_model,
      **extra,
    )
    return parsed, _extract_usage(completion)

  text = _inject_urls(messages[-1]['content'], search_urls)
  search_tools = _build_search_tools(search_enabled, search_urls)
  response = raw_client.models.generate_content(
    model=model,
    contents=_build_contents(text, input_images),
    config=types.GenerateContentConfig(
      system_instruction=system_prompt,
      thinking_config=_build_thinking_config(effort, reasoning_tokens, include_thoughts),
      tools=search_tools,
      temperature=temperature,
      media_resolution=_build_media_resolution(media_resolution),
      top_p=top_p,
      top_k=top_k,
      candidate_count=candidate_count,
      seed=seed,
      stop_sequences=stop_sequences,
      max_output_tokens=max_tokens,
    ),
  )
  return response.text, _extract_usage(response)


def run_image(
    model: str,
    prompt: str,
    input_images: list,
    aspect_ratio: str = '1:1',
    image_size: str = '1K',
    system_prompt=None,
    effort: str = None,
    reasoning_tokens: int = None,
    temperature: float = None,
    include_thoughts: bool = None,
    max_tokens: int = None,
  ):
  raw_client, _ = _get_clients()
  temperature = resolve_temperature(model, temperature)
  response = raw_client.models.generate_content(
    model=model,
    contents=_build_contents(prompt, input_images),
    config=types.GenerateContentConfig(
      system_instruction=system_prompt,
      response_modalities=['IMAGE'],
      image_config=types.ImageConfig(
        aspect_ratio=aspect_ratio,
        image_size=image_size,
      ),
      thinking_config=_build_thinking_config(effort, reasoning_tokens, include_thoughts),
      temperature=temperature,
      max_output_tokens=max_tokens,
    ),
  )

  if not response.candidates:
    block_reason = getattr(response.prompt_feedback, 'block_reason', None)
    raise ValueError(f'Image generation was blocked (reason={block_reason}).')

  for part in response.candidates[0].content.parts or []:
    if part.inline_data:
      return part.inline_data.data, _extract_usage(response)

  finish_reason = response.candidates[0].finish_reason
  raise ValueError(f'No image was returned (finish_reason={finish_reason}).')
