import base64

from openai import OpenAI
import instructor

from .. import config
from .. import param_rules

_raw_client = None
_instructor_client = None
_json_schema_client = None


def _get_clients():
  global _raw_client, _instructor_client
  if _raw_client is None:
    _raw_client = OpenAI(
      api_key=config.OPENAI_API_KEY,
      timeout=config.REQUEST_TIMEOUT,
      max_retries=3,
    )
    _instructor_client = instructor.from_openai(_raw_client)
  return _raw_client, _instructor_client


def _get_json_schema_client():
  # Mode.JSON_SCHEMA (native structured outputs via response_format, no tool calling)
  # -- used when output_model is combined with an explicit effort OR a model that
  # reasons by default (is_openai_reasoning_model). instructor's default mode
  # (Mode.TOOLS) always forces tool_choice whenever there's an output_model, regardless
  # of reasoning_effort or model; confirmed reports that /v1/chat/completions rejects
  # (HTTP 400) forced tool calling combined with reasoning turned on starting with the
  # gpt-5.4 generation -- and some of these models reason by default even without an
  # explicit reasoning_effort in the call (e.g. a user report with gpt-5.6), so
  # checking only "effort was passed" doesn't cover the case. response_format=
  # json_schema doesn't use tool_choice, so the conflict doesn't exist in this mode,
  # regardless of why the model thinks.
  global _json_schema_client
  if _json_schema_client is None:
    raw_client, _ = _get_clients()
    _json_schema_client = instructor.from_openai(raw_client, mode=instructor.Mode.JSON_SCHEMA)
  return _json_schema_client


def _build_image_content(text, input_images):
  if not input_images:
    return text
  blocks = []
  for i, (data, mime) in enumerate(input_images):
    b64 = base64.b64encode(data).decode()
    if mime == 'application/pdf':
      # Chat Completions accepts PDF via a "file" content block (extracts text +
      # page images) -- only not by external URL, base64/file_id only.
      blocks.append({
        'type': 'file',
        'file': {'filename': f'document_{i}.pdf', 'file_data': f'data:{mime};base64,{b64}'},
      })
    else:
      blocks.append({'type': 'image_url', 'image_url': {'url': f'data:{mime};base64,{b64}'}})
  return blocks + [{'type': 'text', 'text': text}]


def _extract_usage(response):
  usage = getattr(response, 'usage', None)
  if usage is None:
    return None
  return {
    'input': usage.prompt_tokens,
    'output': usage.completion_tokens,
    'total': usage.total_tokens,
  }


def run(
    model: str,
    messages: list[dict],
    output_model,
    system_prompt=None,
    input_images: list = None,
    effort: str = None,
    temperature: float = None,
    top_p: float = None,
    frequency_penalty: float = None,
    presence_penalty: float = None,
    seed: int = None,
    stop=None,
    max_tokens: int = None,
  ):
  raw_client, instructor_client = _get_clients()
  if input_images:
    last = messages[-1]
    messages = messages[:-1] + [{**last, 'content': _build_image_content(last['content'], input_images)}]
  if system_prompt:
    messages = [{'role': 'system', 'content': system_prompt}] + messages
  extra = {'reasoning_effort': effort} if effort else {}
  if temperature is not None:
    extra['temperature'] = temperature
  if top_p is not None:
    extra['top_p'] = top_p
  if frequency_penalty is not None:
    extra['frequency_penalty'] = frequency_penalty
  if presence_penalty is not None:
    extra['presence_penalty'] = presence_penalty
  if seed is not None:
    extra['seed'] = seed
  if stop is not None:
    extra['stop'] = stop
  if max_tokens is not None:
    # max_tokens is deprecated/incompatible with the o-series -- Chat Completions uses
    # max_completion_tokens instead.
    extra['max_completion_tokens'] = max_tokens
  if output_model:
    # With effort set OR on a model that reasons by default, use the client in
    # Mode.JSON_SCHEMA (see _get_json_schema_client) -- avoids the forced tool_choice
    # that the default mode (TOOLS) always applies.
    needs_json_schema = effort is not None or param_rules.is_openai_reasoning_model(model)
    structured_client = _get_json_schema_client() if needs_json_schema else instructor_client
    parsed, completion = structured_client.chat.completions.create_with_completion(
      model=model,
      messages=messages,
      response_model=output_model,
      **extra,
    )
    return parsed, _extract_usage(completion)
  else:
    response = raw_client.chat.completions.create(
      model=model,
      messages=messages,
      **extra,
    )
    return response.choices[0].message.content, _extract_usage(response)
