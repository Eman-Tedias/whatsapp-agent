import base64

import anthropic
import instructor

from .. import config

_raw_client = None
_instructor_client = None


def _get_clients():
  global _raw_client, _instructor_client
  if _raw_client is None:
    _raw_client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY)
    _instructor_client = instructor.from_anthropic(_raw_client)
  return _raw_client, _instructor_client


def _build_image_content(text, input_images):
  if not input_images:
    return text
  # image/PDF comes before the text -- order recommended by Anthropic's docs.
  blocks = []
  for data, mime in input_images:
    b64 = base64.b64encode(data).decode()
    if mime == 'application/pdf':
      blocks.append({'type': 'document', 'source': {'type': 'base64', 'media_type': mime, 'data': b64}})
    else:
      blocks.append({'type': 'image', 'source': {'type': 'base64', 'media_type': mime, 'data': b64}})
  return blocks + [{'type': 'text', 'text': text}]


def _build_thinking_kwargs(effort, reasoning_tokens):
  """Build the thinking kwargs for the Anthropic SDK.

  reasoning_tokens (budget_tokens) uses the legacy mechanism (thinking.enabled); effort
  uses the new mechanism (thinking.adaptive + output_config.effort). On Opus 4.5 both
  coexist (effort shapes the whole response, budget_tokens the depth of thinking) --
  that's why these aren't exclusive if/elif branches here; exclusivity on other models
  is enforced by param_rules.check_anthropic_params before reaching this point.
  """
  kwargs = {}
  if reasoning_tokens:
    kwargs['thinking'] = {'type': 'enabled', 'budget_tokens': reasoning_tokens}
  elif effort is not None:
    kwargs['thinking'] = {'type': 'adaptive'}
  if effort is not None:
    kwargs['output_config'] = {'effort': effort}
  return kwargs


def _extract_usage(response):
  usage = getattr(response, 'usage', None)
  if usage is None:
    return None
  return {
    'input': usage.input_tokens,
    'output': usage.output_tokens,
    'total': usage.input_tokens + usage.output_tokens,
  }


def run(
    model: str,
    messages: list[dict],
    output_model,
    max_tokens=None,
    system_prompt=None,
    input_images: list = None,
    reasoning_tokens: int = None,
    effort: str = None,
    temperature: float = None,
    top_p: float = None,
    top_k: int = None,
  ):
  raw_client, instructor_client = _get_clients()
  if input_images:
    last = messages[-1]
    messages = messages[:-1] + [{**last, 'content': _build_image_content(last['content'], input_images)}]
  if max_tokens is None:
    # budget_tokens can be sized directly (it's a token count); effort is qualitative
    # (low/high/etc.) with no exact conversion -- use a generous enough ceiling to
    # avoid truncating a high-effort response (thinking counts toward max_tokens),
    # instead of the old flat 1024, which was only sized for the no-thinking case.
    if reasoning_tokens:
      max_tokens = int(reasoning_tokens * 1.2)
    elif effort is not None:
      max_tokens = 16000
    else:
      max_tokens = 1024
  extra = _build_thinking_kwargs(effort, reasoning_tokens)
  if temperature is not None:
    extra['temperature'] = temperature
  if top_p is not None:
    extra['top_p'] = top_p
  if top_k is not None:
    extra['top_k'] = top_k
  if output_model:
    parsed, completion = instructor_client.messages.create_with_completion(
      model=model,
      max_tokens=max_tokens,
      system=system_prompt,
      messages=messages,
      response_model=output_model,
      **extra,
    )
    return parsed, _extract_usage(completion)
  else:
    response = raw_client.messages.create(
      model=model,
      max_tokens=max_tokens,
      system=system_prompt,
      messages=messages,
      **extra,
    )
    text = next((block.text for block in response.content if block.type == 'text'), None)
    if text is None:
      raise ValueError('Anthropic did not return any text block in the response.')
    return text, _extract_usage(response)
