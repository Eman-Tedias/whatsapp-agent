from typing import Literal, Optional
from pydantic import create_model, Field, BaseModel

FIELD_TYPES = {
  'string': str,
  'str': str,
  'int': int,
  'integer': int,
  'float': float,
  'number': float,
  'bool': bool,
  'boolean': bool,
  'list': list,
  'array': list,
  'dict': dict,
  'object': dict,
}

class Criteria(BaseModel):
  description: str
  type: Literal['float', 'bool']
  # Per-criterion pass threshold. For type='bool' the judge only ever grades
  # 0.0/1.0, so this should be 1.0 to require an exact pass.
  threshold: float = Field(ge=0.0, le=1.0)

class EvalConfig(BaseModel):
  judge_model: str | None = None
  criteria: dict[str, Criteria]
  obs: str | None = None

class EvalItem(BaseModel):
  criteria: str
  reason: str
  grade: float = Field(ge=0.0, le=1.0)

class EvalList(BaseModel):
  items: list[EvalItem]

def _build_field(field_def: dict, model_name: str = 'Nested'):
  field_type = FIELD_TYPES.get(field_def.get('type', 'string'), str)

  if field_type == list:
    item_type = FIELD_TYPES.get(field_def.get('items', 'string'), str)
    field_type = list[item_type]

  elif field_type == dict and 'fields' in field_def:
    field_type = build_output_model(field_def['fields'], name=model_name)

  if 'literal' in field_def:
    field_type = Literal[tuple(field_def['literal'])]

  default = field_def.get('default', ...)

  if field_def.get('optional', False):
    field_type = Optional[field_type]
    default = None if default is ... else default

  if 'description' in field_def:
    return field_type, Field(default, description=field_def['description'])

  return field_type, default


def build_output_model(schema: dict, name: str = 'StructuredOutput'):
  fields = {
    key: _build_field(field_def, model_name=key.capitalize())
    for key, field_def in schema.items()
  }
  return create_model(name, **fields)
