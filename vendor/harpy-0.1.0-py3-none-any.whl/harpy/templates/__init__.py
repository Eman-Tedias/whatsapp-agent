from . import text, image

TEMPLATES = {'text': text, 'image': image}
