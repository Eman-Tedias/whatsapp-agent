ENV_KEYS = {
  'GEMINI_API_KEY': 'Gemini key (aistudio.google.com) -- required for image generation, unless you use Vertex AI (see VERTEX_PROJECT below)',
  'VERTEX_PROJECT': 'Google Cloud project ID -- alternative to GEMINI_API_KEY, routes through Vertex AI instead of the public Gemini API (optional)',
  'VERTEX_LOCATION': 'Vertex AI region, e.g. us-central1 (optional, only matters if VERTEX_PROJECT is set)',
}

MAIN_TEMPLATE = '''# >>>NOTE
"""
Quick tour of harpy's image generation API.

Before running:
  1. pip install python-dotenv
  2. copy .env.example to .env and fill in the keys you plan to use
"""
# <<<NOTE

from dotenv import load_dotenv

# >>>NOTE
# load .env into the environment before importing harpy, so the keys
# are already available by the time you need them.
# <<<NOTE

load_dotenv()

from harpy import image

# >>>NOTE
# image generation currently only works with the "gemini" provider.
#
# image.gemini(model=..., aspect_ratio=..., image_size=..., thinking_budget=...,
#              thinking_level=..., include_thoughts=..., temperature=..., images=..., max_tokens=...)
#     .prompts(user=...)                 -> describes the image you want generated
#     .run()                              -> executes the call and returns the raw image bytes (not a ready-made image object)
# <<<NOTE

# >>>NOTE
# generates an image and saves it to a .png file -- swap the prompt for your own use case.
# <<<NOTE
image_bytes = (
    image.gemini(aspect_ratio="1:1", image_size="1K")
    .prompts(user="an astronaut cat painted in watercolor")
    .run()
)
with open("generated_image.png", "wb") as f:
    f.write(image_bytes)
print("Image saved to generated_image.png")
'''

SNIPPET_TEMPLATE = '''image_bytes = (
    image.gemini(aspect_ratio="1:1", image_size="1K")
    .prompts(user="")
    .run()
)
'''
