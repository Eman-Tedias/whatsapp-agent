ENV_KEYS = {
  'ANTHROPIC_API_KEY': "Anthropic key (console.anthropic.com) -- required to use harpy.text.anthropic(...)",
  'OPENAI_API_KEY': "OpenAI key (platform.openai.com) -- required to use harpy.text.openai(...)",
  'GEMINI_API_KEY': "Gemini key (aistudio.google.com) -- required to use harpy.text.gemini(...), unless you use Vertex AI (see VERTEX_PROJECT below)",
  'GROQ_API_KEY': "Groq key (console.groq.com) -- required to use harpy.text.groq(...)",
  'VERTEX_PROJECT': 'Google Cloud project ID -- alternative to GEMINI_API_KEY, routes through Vertex AI instead of the public Gemini API (optional)',
  'VERTEX_LOCATION': 'Vertex AI region, e.g. us-central1 (optional, only matters if VERTEX_PROJECT is set)',
  'REQUEST_TIMEOUT': 'timeout in seconds for LLM calls (optional, default: 120)',
}

SNIPPET_TEMPLATE = '''result = (
    text.anthropic()  # or text.openai(...) / text.gemini(...) / text.groq(...)
    .prompts(
        system="",
        user="",
    )
    .output({})
    .run()
)
'''

MAIN_TEMPLATE = '''# >>>NOTE
"""
Quick tour of the harpy API -- shows what each method does.

Before running:
  1. pip install python-dotenv
  2. copy .env.example to .env and fill in the keys you plan to use
"""
# <<<NOTE

from dotenv import load_dotenv

# >>>NOTE
# load .env into the environment before importing harpy, so the keys
# are already available by the time you need them.
# <<<NOTE

load_dotenv()


# >>>NOTE
# `schema` describes the structured output the model should return.
# each dict key becomes a field on the output model. per-field options:
#   "type":        "string" | "int" | "float" | "bool" | "list" | "dict" (default: "string")
#   "items":       element type, when "type" is "list" (e.g. "string")
#   "fields":      nested dict, when "type" is "dict" (same shape as schema)
#   "literal":     list of allowed fixed values (e.g. ["option_a", "option_b"])
#   "optional":    True/False -- if True, the field may be missing (default: False)
#   "default":     value used when the field is optional and the model omits it
#   "description": text that helps the model understand what to put in the field
# <<<NOTE
schema = {
    "text_field": {
        "type": "string",
        "description": "a plain text field",
    },
    "category_field": {
        "type": "string",
        "literal": ["option_a", "option_b", "option_c"],
        "description": "a field restricted to a fixed set of values",
    },
    "list_field": {
        "type": "list",
        "items": "string",
        "description": "a list of items of the type declared in 'items'",
    },
    "nested_field": {
        "type": "dict",
        "optional": True,
        "description": "an optional field with its own sub-fields",
        "fields": {
            "sub_field": {
                "type": "string",
                "optional": True,
                "default": "",
                "description": "a sub-field inside 'nested_field'",
            },
        },
    },
}

from harpy import text

# >>>NOTE
# each provider is its own function with real, named parameters -- passing a
# parameter that provider/model doesn't support raises before any network request:
#
# text.anthropic(model=..., thinking_budget_tokens=..., thinking_effort=..., temperature=..., top_p=..., top_k=..., images=...)
# text.openai(model=..., reasoning_effort=..., temperature=..., top_p=..., frequency_penalty=..., presence_penalty=..., seed=..., stop=..., max_tokens=..., images=...)
# text.gemini(model=..., thinking_budget=..., thinking_level=..., include_thoughts=..., search=..., temperature=..., images=..., media_resolution=..., top_p=..., top_k=..., candidate_count=..., seed=..., stop_sequences=..., max_tokens=...)
# text.groq(model=..., reasoning_effort=..., temperature=..., max_tokens=...)
#
# the object returned by any of the above supports:
#     .prompts(system=..., user=...)             -> sets the prompts; user can contain {placeholders}
#     .context(**kwargs)                         -> fills the {placeholders} in the user prompt
#     .output(schema)                            -> turns on structured output validated against schema (see above)
#     .fallback()                                -> if the main provider fails, retries the other providers that have an API key set
#     .fallback(model="provider/model")          -> retries only that specific fallback instead of the automatic list
#     .fallback(model=["p1/m1", "p2/m2"])        -> retries these specific fallbacks, in this order
#     .run()                                     -> executes the call (with automatic retries) and returns the result
# <<<NOTE

def main():
    # >>>NOTE
    """Minimal example: swap the prompts and schema above for your own use case."""
    # <<<NOTE
    result = (
        text.anthropic()
        .prompts(
            system="You are an assistant that extracts structured information from text.",
            user="Text: {text}",
        )
        .context(text="Jane Doe placed an order for 3 items on 2024-01-15.")
        .output(schema)
        .run()
    )
    print(result)


if __name__ == "__main__":
    main()
'''
