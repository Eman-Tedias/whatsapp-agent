import argparse
import sys
from pathlib import Path

from .templates import TEMPLATES

def strip_comments(source):
  out_lines = []
  skip = False
  for line in source.splitlines():
    stripped = line.strip()
    if stripped == '# >>>NOTE':
      skip = True
      continue
    if stripped == '# <<<NOTE':
      skip = False
      continue
    if not skip:
      out_lines.append(line)
  return '\n'.join(out_lines) + '\n'

def build_parser():
  parser = argparse.ArgumentParser(prog='harpy')
  subparsers = parser.add_subparsers(dest='command', required=True)

  scaffold_parser = subparsers.add_parser(
    'scaffold', help="generate a starter file that shows harpy's API"
  )
  scaffold_parser.add_argument('kind', choices=sorted(TEMPLATES.keys()))
  scaffold_parser.add_argument(
    '--noenv', action='store_true', help='skip generating .env.example'
  )
  scaffold_parser.add_argument(
    '--nonotes',
    action='store_true',
    help='strip the explanatory notes and docstrings from the generated file',
  )

  snippet_parser = subparsers.add_parser(
    'snippet', help='print just the call, ready to paste into your own file'
  )
  snippet_parser.add_argument('kind', choices=sorted(TEMPLATES.keys()))

  return parser


def _build_env_content(env_keys, nonotes):
  lines = []
  for key, description in env_keys.items():
    if not nonotes:
      lines.append(f'# {description}')
    lines.append(f'{key}=')
    lines.append('')
  return '\n'.join(lines).rstrip() + '\n'


def _ensure_gitignore_has_env():
  gitignore = Path('.gitignore')
  if not gitignore.exists():
    gitignore.write_text('.env\n')
    return

  content = gitignore.read_text()
  if '.env' in content.splitlines():
    return

  if content and not content.endswith('\n'):
    content += '\n'
  content += '.env\n'
  gitignore.write_text(content)


def generate(kind, noenv, nonotes):
  module = TEMPLATES[kind]

  main_path = Path(f'{kind}_starter.py')
  env_path = Path('.env.example')

  if main_path.exists():
    print(
      f'{main_path} already exists, remove or rename it first',
      file=sys.stderr,
    )
    sys.exit(1)

  main_source = module.MAIN_TEMPLATE
  if nonotes:
    main_source = strip_comments(main_source)
  main_path.write_text(main_source)

  generated = [str(main_path)]
  if not noenv:
    if env_path.exists():
      print(f'{env_path} already exists, left untouched')
    else:
      env_path.write_text(_build_env_content(module.ENV_KEYS, nonotes))
      generated.append(str(env_path))
    _ensure_gitignore_has_env()

  print(f"generated: {', '.join(generated)}")


def main():
  parser = build_parser()
  args = parser.parse_args()

  if args.command == 'scaffold':
    generate(args.kind, args.noenv, args.nonotes)
  elif args.command == 'snippet':
    print(TEMPLATES[args.kind].SNIPPET_TEMPLATE, end='')


if __name__ == '__main__':
  main()
