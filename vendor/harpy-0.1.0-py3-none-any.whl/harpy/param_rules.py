"""Parameter x model compatibility rules, per provider.

Each `check_*_params` runs when the provider factory is constructed (harpy.text.<provider>(),
harpy.image.<provider>()), before any network request. Two kinds of problem, handled
differently:

- "this parameter doesn't exist on this model" (e.g. temperature on a model that dropped
  sampling controls, reasoning_effort on a model that can't be tuned) -- silently dropped
  (becomes None) and the call proceeds without it, as long as dropping it doesn't fully
  disable a central mechanism the caller asked for (thinking, for Anthropic/Gemini -- see
  the comment in each function).
- "these two parameters conflict with each other, or the value is invalid in a way only
  the caller can resolve" -- still raises ProviderParameterError, because there's no way to
  silently drop one side without changing what was actually requested (e.g.
  thinking_budget_tokens >= max_tokens on Gemini silently truncates the response;
  thinking_budget_tokens/thinking_effort together outside Opus 4.5).

Each `check_*_params` returns a dict with the already-adjusted parameters (some may have
become None) -- callers use the return value, not the original kwargs.

Organized per provider (not per individual model, which would go stale on every release)
and centralized in its own file, separate from providers/*.py: the two evolve at different
paces (the capability table changes with every model release; the run() signature only
changes when the SDK changes).
"""

import re

from .exceptions import ProviderParameterError

# --- Anthropic --- grouped by model tier/generation, not by individual model (an
# individual list would go stale on every new release).

# Newest tier (Fable 5, Opus 4.8/4.7, Sonnet 5) -- ANTHROPIC_NO_BUDGET_TOKENS and
# ANTHROPIC_NO_TEMPERATURE are conceptually distinct capabilities that happen to
# coincide because they're the same model generation; they reference the same
# constant on purpose (two identical sets defined separately have already drifted
# silently once). If a future release drops one capability without the other, this
# is where the two sets split.
_ANTHROPIC_NEWEST_TIER = {
  'claude-fable-5', 'claude-opus-4-8', 'claude-opus-4-7', 'claude-sonnet-5',
}
ANTHROPIC_NO_BUDGET_TOKENS = _ANTHROPIC_NEWEST_TIER
# thinking_effort (adaptive + output_config.effort) -- models that only have the legacy
# mechanism (budget_tokens) and reject effort. Opus 4.5 is NOT here: it's the only
# extended-thinking-only model that supports effort (see ANTHROPIC_LIMITED_EFFORT_MODELS),
# composing with budget_tokens instead of being mutually exclusive.
ANTHROPIC_NO_THINKING_EFFORT = {
  'claude-haiku-4-5', 'claude-haiku-4-5-20251001',
  'claude-sonnet-4-5', 'claude-sonnet-4-5-20250929',
}
# Opus 4.5: accepts thinking_effort but only the levels below (no xhigh/max) -- it's
# the only model where thinking_effort and thinking_budget_tokens compose instead of
# being mutually exclusive (effort shapes the whole response, budget_tokens the depth
# of thinking -- confirmed in the official extended thinking docs).
ANTHROPIC_LIMITED_EFFORT_MODELS = {
  'claude-opus-4-5', 'claude-opus-4-5-20251101',
}
ANTHROPIC_LIMITED_EFFORT_LEVELS = {'low', 'medium', 'high'}
ANTHROPIC_NO_TEMPERATURE = _ANTHROPIC_NEWEST_TIER
ANTHROPIC_MIN_BUDGET_TOKENS = 1024


def check_anthropic_params(model, temperature=None, top_p=None, top_k=None, thinking_effort=None,
                            thinking_budget_tokens=None, max_tokens=None):
  # Sampling (temperature/top_p/top_k): "this parameter doesn't exist on this model" --
  # dropping it doesn't affect the central request (thinking), just the garnish. Silent.
  if model in ANTHROPIC_NO_TEMPERATURE:
    temperature, top_p, top_k = None, None, None
  elif thinking_budget_tokens is not None:
    # On older models the restriction only exists while thinking (budget_tokens) is on:
    # temperature and top_k become incompatible, top_p is only accepted between 0.95-1.0.
    if temperature is not None:
      temperature = None
    if top_k is not None:
      top_k = None
    if top_p is not None and not (0.95 <= top_p <= 1.0):
      top_p = None

  # Invalid thinking_budget_tokens/thinking_effort: still an error whenever dropping it
  # would fully disable thinking (a central mechanism the caller asked for), not garnish --
  # explicit design decision.
  if thinking_budget_tokens is not None:
    if model in ANTHROPIC_NO_BUDGET_TOKENS:
      raise ProviderParameterError('anthropic', model, 'thinking_budget_tokens',
        'This model only accepts adaptive thinking (thinking_budget_tokens was removed) '
        '-- use thinking_effort.')
    if thinking_budget_tokens < ANTHROPIC_MIN_BUDGET_TOKENS:
      raise ProviderParameterError('anthropic', model, 'thinking_budget_tokens',
        f'thinking_budget_tokens must be >= {ANTHROPIC_MIN_BUDGET_TOKENS} (API minimum).')
    if max_tokens is not None and thinking_budget_tokens >= max_tokens:
      raise ProviderParameterError('anthropic', model, 'thinking_budget_tokens',
        'thinking_budget_tokens must be smaller than max_tokens (thinking counts toward the '
        'output limit).')

  if thinking_effort is not None:
    if model in ANTHROPIC_NO_THINKING_EFFORT:
      raise ProviderParameterError('anthropic', model, 'thinking_effort',
        "This model doesn't have adaptive/effort thinking -- use thinking_budget_tokens.")
    if model in ANTHROPIC_LIMITED_EFFORT_MODELS and thinking_effort not in ANTHROPIC_LIMITED_EFFORT_LEVELS:
      raise ProviderParameterError('anthropic', model, 'thinking_effort',
        f'This model only accepts thinking_effort in {sorted(ANTHROPIC_LIMITED_EFFORT_LEVELS)} (no xhigh/max).')

  # thinking_effort and thinking_budget_tokens are mutually exclusive, except on Opus 4.5
  # (the only model where the API lets both coexist -- see ANTHROPIC_LIMITED_EFFORT_MODELS).
  if (thinking_effort is not None and thinking_budget_tokens is not None
      and model not in ANTHROPIC_LIMITED_EFFORT_MODELS):
    raise ProviderParameterError('anthropic', model, 'thinking_effort',
      'thinking_effort and thinking_budget_tokens are mutually exclusive on this model -- pick one.')

  return {
    'temperature': temperature, 'top_p': top_p, 'top_k': top_k,
    'thinking_effort': thinking_effort, 'thinking_budget_tokens': thinking_budget_tokens,
    'max_tokens': max_tokens,
  }


# --- OpenAI --- detected by name pattern; a fixed model list would go stale on every
# release (gpt-5.x, new o-series).

_OPENAI_REASONING_RE = re.compile(r'^(o1|o3|o4)(-|$)|^gpt-5')
_OPENAI_REASONING_EXCEPTIONS = {'gpt-5-chat-latest', 'chatgpt-4o-latest'}
_OPENAI_NO_REASONING_EFFORT = {'o1-mini', 'gpt-5-search-api'}
# gpt-5.4 confirmed via real user reports (HTTP 400 "stop is not supported"), even though
# the official docs still only mention o3/o4-mini -- the docs lag behind actual API
# behavior. Not generalized to the whole gpt-5.x family because the exact boundary
# (5.5/5.6 onward) isn't confirmed.
_OPENAI_NO_STOP = {'o3', 'o3-mini', 'o4-mini', 'gpt-5.4'}


def is_openai_reasoning_model(model):
  if model in _OPENAI_REASONING_EXCEPTIONS:
    return False
  # Every gpt-5.x generation gets its own non-reasoning "-chat-latest" variant
  # (gpt-5-chat-latest, gpt-5.1-chat-latest, ...) -- checking the suffix instead of
  # keeping a fixed list avoids going stale on every new release.
  if model.endswith('-chat-latest'):
    return False
  return bool(_OPENAI_REASONING_RE.match(model))


def check_openai_params(model, temperature=None, reasoning_effort=None, top_p=None,
                         frequency_penalty=None, presence_penalty=None, stop=None):
  # Every incompatibility here is "this parameter doesn't exist on this model" -- none
  # of them disables a central mechanism with no alternative (a reasoning model keeps
  # reasoning at its own default even without a tunable reasoning_effort), so it's
  # dropped silently instead of raising.
  if is_openai_reasoning_model(model):
    temperature, top_p, frequency_penalty, presence_penalty = None, None, None, None
  if reasoning_effort is not None and model in _OPENAI_NO_REASONING_EFFORT:
    reasoning_effort = None
  if stop is not None and model in _OPENAI_NO_STOP:
    stop = None
  return {
    'temperature': temperature, 'reasoning_effort': reasoning_effort, 'top_p': top_p,
    'frequency_penalty': frequency_penalty, 'presence_penalty': presence_penalty, 'stop': stop,
  }


# --- Gemini --- besides the pattern above, thinking_budget and thinking_level are
# mutually exclusive (HTTP 400 if both are passed together), and the valid
# thinking_level subset varies by model within the 3.x series. "gemini-3-pro-preview"
# (deprecated) is intentionally not listed here anymore -- see
# ai.google.dev/gemini-api/docs/deprecations.

_GEMINI_THINKING_LEVEL_SUBSET = {
  'gemini-3.1-pro-preview': {'low', 'medium', 'high'},
  'gemini-3-flash-preview': {'minimal', 'low', 'medium', 'high'},
  'gemini-3.1-flash-lite': {'minimal', 'low', 'medium', 'high'},
  'gemini-3.5-flash': {'minimal', 'low', 'medium', 'high'},
  'gemini-3.6-flash': {'minimal', 'low', 'medium', 'high'},
}


def _is_gemini_3_family(model):
  return model.startswith('gemini-3')


def check_gemini_params(model, thinking_budget=None, thinking_level=None, max_tokens=None, candidate_count=None):
  # Mutex thinking_budget x thinking_level: both were requested by the caller, silently
  # dropping one would change which thinking mechanism actually applied -- still an error.
  if thinking_budget is not None and thinking_level is not None:
    raise ProviderParameterError('gemini', model, 'thinking_level',
      'thinking_budget and thinking_level are mutually exclusive on Gemini -- pick one.')
  if thinking_level is not None:
    # Value outside this model's subset -- drop it (thinking stays on at the model's
    # default level, just not the exact level requested; thinking itself isn't disabled).
    allowed = _GEMINI_THINKING_LEVEL_SUBSET.get(model)
    if allowed and thinking_level.lower() not in allowed:
      thinking_level = None
  # thinking_budget and max_output_tokens share the same token limit on Gemini -- the API
  # doesn't validate the order, it just silently truncates the response if there's no room
  # left for visible output (a documented gotcha in several googleapis/python-genai
  # issues). Silently dropping either one would produce exactly that silent truncation --
  # still an error.
  if thinking_budget is not None and max_tokens is not None and thinking_budget >= max_tokens:
    raise ProviderParameterError('gemini', model, 'max_tokens',
      'thinking_budget must be smaller than max_tokens -- they share the same token limit, '
      'and the Gemini API silently truncates the response (no error) if there is no room left.')
  # candidate_count > 1 was disabled across the whole Gemini 3.x family (a documented
  # regression) -- drop to 1 candidate (the default), doesn't affect the central request.
  if candidate_count is not None and candidate_count > 1 and _is_gemini_3_family(model):
    candidate_count = None
  return {
    'thinking_budget': thinking_budget, 'thinking_level': thinking_level,
    'max_tokens': max_tokens, 'candidate_count': candidate_count,
  }
