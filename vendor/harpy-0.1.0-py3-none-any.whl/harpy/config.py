import os

OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')
GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY')
ANTHROPIC_API_KEY = os.environ.get('ANTHROPIC_API_KEY')
GROQ_API_KEY = os.environ.get('GROQ_API_KEY')

VERTEX_PROJECT = os.environ.get('VERTEX_PROJECT')
VERTEX_LOCATION = os.environ.get('VERTEX_LOCATION', 'us-central1')

REQUEST_TIMEOUT = int(os.environ.get('REQUEST_TIMEOUT', 120))

LANGFUSE_ENABLED = os.environ.get('LANGFUSE_ENABLED', 'true').lower() == 'true'
LANGFUSE_PUBLIC_KEY = os.environ.get('LANGFUSE_PUBLIC_KEY')
LANGFUSE_SECRET_KEY = os.environ.get('LANGFUSE_SECRET_KEY')
LANGFUSE_HOST = os.environ.get('LANGFUSE_HOST', 'https://cloud.langfuse.com')
