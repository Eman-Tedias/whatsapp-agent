"""Entry point namespace for text generation: harpy.text.<provider>(model=..., ...).

Each function has a real named signature (not **kwargs) -- a wrong parameter name
becomes a plain Python TypeError, and parameter x model compatibility (things the
signature alone can't catch, like temperature on a reasoning model, or thinking_budget
+ thinking_level together on Gemini) is checked here, before any network request, via
the param_rules.py tables.

TextCall lives here (not in core.py) -- it's the state + text-specific setters
(.output(), _set_search(), _set_max_tokens(), etc.), only reachable through the
factories below. core.py only has what's shared with ImageCall (LLM).
"""

import json
import time
import warnings

from pydantic import BaseModel

from . import catalog
from . import param_rules
from . import evaluation
from .core import LLM, _RETRY_ATTEMPTS, _RETRY_BACKOFF_SECONDS, _serialize_output
from .schema import build_output_model
from .providers import openai as openai_provider, gemini as gemini_provider, anthropic as anthropic_provider, groq as groq_provider


def _extract_text_content(result):
  serialized = _serialize_output(result)
  if isinstance(serialized, dict):
    return json.dumps(serialized, ensure_ascii=False, indent=2)
  return str(serialized)


class TextCall(LLM):

  def __init__(self, provider, model=None):
    super().__init__(provider, model)
    self._output_model = None
    self._search_enabled = False
    self._search_urls = []
    self._media_resolution = None

  def output(self, schema):
    if self._search_enabled and self.provider == 'gemini':
      warnings.warn(
        'harpy.text.gemini(search=True) + .output(schema) makes 2 API calls (Gemini '
        "does not allow search and controlled generation in the same call) -- doubles "
        'cost and latency. thinking (thinking_budget/thinking_level) + .output(schema) '
        "doesn't have this problem, it runs in a single call.",
        UserWarning,
      )
    if isinstance(schema, type) and issubclass(schema, BaseModel):
      self._output_model = schema
    else:
      self._output_model = build_output_model(schema)
    return self

  def _set_media_resolution(self, value):
    self._media_resolution = value
    return self

  def _set_search(self, urls=None):
    self._search_enabled = True
    if urls is None:
      self._search_urls = None
    elif isinstance(urls, list):
      self._search_urls = urls
    elif isinstance(urls, str):
      self._search_urls = [urls]
    else:
      raise TypeError(f'urls must be a list, a string or None (received: {type(urls)})')
    return self

  def _call(self, provider, model, messages, schema, system_prompt, search_enabled, search_urls,
             input_images, effort, reasoning_tokens, max_tokens=None, temperature=None,
             include_thoughts=None, media_resolution=None, extra_params=None):
    extra_params = extra_params or {}
    if provider == 'openai':
      return openai_provider.run(
        model=model, messages=messages, output_model=schema, system_prompt=system_prompt,
        input_images=input_images, effort=effort, temperature=temperature,
        max_tokens=max_tokens, **extra_params,
      )
    elif provider == 'gemini':
      return gemini_provider.run(
        model=model, messages=messages, output_model=schema, input_images=input_images,
        search_enabled=search_enabled, search_urls=search_urls, system_prompt=system_prompt,
        effort=effort, reasoning_tokens=reasoning_tokens, temperature=temperature,
        include_thoughts=include_thoughts, media_resolution=media_resolution,
        max_tokens=max_tokens, **extra_params,
      )
    elif provider == 'anthropic':
      return anthropic_provider.run(
        model=model, messages=messages, output_model=schema, max_tokens=max_tokens,
        system_prompt=system_prompt, input_images=input_images, reasoning_tokens=reasoning_tokens,
        effort=effort, temperature=temperature, **extra_params,
      )
    elif provider == 'groq':
      return groq_provider.run(
        model=model, messages=messages, output_model=schema, system_prompt=system_prompt,
        effort=effort, temperature=temperature, max_tokens=max_tokens, **extra_params,
      )
    else:
      raise ValueError(f"Provider '{provider}' is invalid -- use 'openai', 'gemini', 'anthropic' or 'groq'.")

  def _run_with_fallbacks(self, provider, model, messages, schema, system_prompt, input_images,
                            search_enabled, search_urls, effort, reasoning_tokens, max_tokens,
                            fallbacks, temperature=None, include_thoughts=None, media_resolution=None,
                            extra_params=None):
    last_error = None
    for attempt in range(_RETRY_ATTEMPTS):
      try:
        return self._traced_call(
          name=f'harpy.call ({provider})',
          fn=lambda: self._call(
            provider=provider, model=model, messages=messages, schema=schema,
            system_prompt=system_prompt, search_enabled=search_enabled, search_urls=search_urls,
            input_images=input_images, effort=effort, reasoning_tokens=reasoning_tokens,
            max_tokens=max_tokens, temperature=temperature, include_thoughts=include_thoughts,
            media_resolution=media_resolution, extra_params=extra_params,
          ),
          input_data=messages, model=model,
          metadata={'provider': provider, 'attempt': attempt + 1},
        )
      except Exception as e:
        last_error = e
        if attempt < _RETRY_ATTEMPTS - 1:
          time.sleep(_RETRY_BACKOFF_SECONDS * (2 ** attempt))

    for fallback in fallbacks:
      fb_provider, fb_model = catalog.split_provider_model(fallback, catalog.DEFAULT_MODELS)
      fb_extra_params = extra_params if fb_provider == provider else None
      try:
        return self._traced_call(
          name=f'harpy.fallback ({fb_provider})',
          fn=lambda: self._call(
            provider=fb_provider, model=fb_model, messages=messages, schema=schema,
            system_prompt=system_prompt, search_enabled=search_enabled, search_urls=search_urls,
            input_images=input_images, effort=effort, reasoning_tokens=reasoning_tokens,
            max_tokens=max_tokens, temperature=temperature, include_thoughts=include_thoughts,
            media_resolution=media_resolution, extra_params=fb_extra_params,
          ),
          input_data=messages, model=fb_model,
          metadata={'provider': fb_provider, 'fallback': True},
        )
      except Exception as e:
        last_error = e
        continue
    raise last_error

  def _run_body(self):
    provider = self.provider
    model = self._model or catalog.DEFAULT_MODELS[provider]
    system_prompt = self._system
    user_prompt = self._interpolated_prompt()
    schema = self._output_model
    max_tokens = self._max_tokens
    fallbacks = self._fallbacks
    effort = self._reasoning_effort
    reasoning_tokens = self._reasoning_tokens
    search_enabled = self._search_enabled
    search_urls = self._search_urls
    temperature = self._temperature
    include_thoughts = self._include_thoughts
    media_resolution = self._media_resolution
    extra_params = self._provider_kwargs
    input_images = [self._normalize_image(source=s) for s in self._input_images]
    self._check_guardrail(user_prompt)

    def _generate(current_user_prompt):
      messages = [{'role': 'user', 'content': current_user_prompt}]
      if self._output_model and self._search_enabled and provider == 'gemini':
        reasoning_text = self._traced_span(
          name='harpy.run.reasoning',
          fn=lambda: self._run_with_fallbacks(
            provider=provider, model=model, messages=messages, schema=None,
            system_prompt=system_prompt, input_images=input_images,
            search_enabled=search_enabled, search_urls=search_urls,
            effort=effort, reasoning_tokens=reasoning_tokens, max_tokens=max_tokens,
            fallbacks=fallbacks, temperature=temperature,
            include_thoughts=include_thoughts, media_resolution=media_resolution,
            extra_params=extra_params,
          ),
          input_data=messages, metadata={'provider': provider, 'stage': 'reasoning'},
        )
        extraction_messages = [{'role': 'user', 'content': f'Structure the information from this text into the requested format:\n\n{reasoning_text}'}]
        return self._traced_span(
          name='harpy.run.extraction',
          fn=lambda: self._run_with_fallbacks(
            provider=provider, model=model, messages=extraction_messages,
            schema=schema, system_prompt=system_prompt, input_images=[],
            search_enabled=False, search_urls=None,
            effort=None, reasoning_tokens=None,
            max_tokens=max_tokens, fallbacks=fallbacks,
            temperature=temperature, include_thoughts=None, media_resolution=None,
            extra_params=extra_params,
          ),
          input_data=extraction_messages, metadata={'provider': provider, 'stage': 'extraction'},
        )

      return self._run_with_fallbacks(
        provider=provider, model=model, messages=messages, schema=schema,
        system_prompt=system_prompt, input_images=input_images,
        search_enabled=search_enabled, search_urls=search_urls,
        effort=effort, reasoning_tokens=reasoning_tokens, max_tokens=max_tokens,
        fallbacks=fallbacks, temperature=temperature,
        include_thoughts=include_thoughts, media_resolution=media_resolution,
        extra_params=extra_params,
      )

    result = _generate(user_prompt)
    output = {'response': result}

    if self._eval_enabled:
      result, eval_info = self._run_eval_gate(
        result=result,
        regenerate=lambda feedback: _generate(user_prompt + evaluation.RETRY_FEEDBACK_TEMPLATE.format(feedback=feedback)),
        extract_content=_extract_text_content,
        content_type='text',
      )
      output['response'] = result
      output['eval'] = eval_info

    return output

  def run(self):
    return self._traced_run(
      name='harpy.run',
      fn=self._run_body,
      input_data=self._interpolated_prompt(),
      metadata={'provider': self.provider},
    )['response']


def gemini(
    model=None,
    thinking_budget=None,
    thinking_level=None,
    include_thoughts=None,
    search=None,
    search_urls=None,
    temperature=None,
    images=None,
    media_resolution=None,
    top_p=None,
    top_k=None,
    candidate_count=None,
    seed=None,
    stop_sequences=None,
    max_tokens=None,
  ):
  model = model or catalog.DEFAULT_MODELS['gemini']
  p = param_rules.check_gemini_params(model, thinking_budget=thinking_budget, thinking_level=thinking_level,
                                       max_tokens=max_tokens, candidate_count=candidate_count)

  call = TextCall(provider='gemini', model=model)
  if p['thinking_budget'] is not None or p['thinking_level'] is not None or include_thoughts is not None:
    call._set_thinking(reasoning_tokens=p['thinking_budget'], effort=p['thinking_level'], include_thoughts=include_thoughts)
  if search:
    call._set_search(urls=search_urls)
  if temperature is not None:
    call._set_temperature(temperature)
  if images is not None:
    call._set_images(images)
  if media_resolution is not None:
    call._set_media_resolution(media_resolution)
  if p['max_tokens'] is not None:
    call._set_max_tokens(p['max_tokens'])
  call._set_provider_kwargs(top_p=top_p, top_k=top_k, candidate_count=p['candidate_count'],
                             seed=seed, stop_sequences=stop_sequences)
  return call


def openai(model=None, reasoning_effort=None, temperature=None, top_p=None,
           frequency_penalty=None, presence_penalty=None, seed=None, stop=None, max_tokens=None,
           images=None):
  model = model or catalog.DEFAULT_MODELS['openai']
  p = param_rules.check_openai_params(model, temperature=temperature, reasoning_effort=reasoning_effort,
                                       top_p=top_p, frequency_penalty=frequency_penalty,
                                       presence_penalty=presence_penalty, stop=stop)

  call = TextCall(provider='openai', model=model)
  if p['reasoning_effort'] is not None:
    call._set_thinking(effort=p['reasoning_effort'])
  if p['temperature'] is not None:
    call._set_temperature(p['temperature'])
  if max_tokens is not None:
    call._set_max_tokens(max_tokens)
  if images is not None:
    call._set_images(images)
  call._set_provider_kwargs(top_p=p['top_p'], frequency_penalty=p['frequency_penalty'],
                             presence_penalty=p['presence_penalty'], seed=seed, stop=p['stop'])
  return call


def anthropic(model=None, thinking_budget_tokens=None, thinking_effort=None, temperature=None,
              max_tokens=None, top_p=None, top_k=None, images=None):
  model = model or catalog.DEFAULT_MODELS['anthropic']
  p = param_rules.check_anthropic_params(model, temperature=temperature, top_p=top_p, top_k=top_k,
                                          thinking_effort=thinking_effort,
                                          thinking_budget_tokens=thinking_budget_tokens,
                                          max_tokens=max_tokens)

  call = TextCall(provider='anthropic', model=model)
  if p['thinking_budget_tokens'] is not None or p['thinking_effort'] is not None:
    call._set_thinking(reasoning_tokens=p['thinking_budget_tokens'], effort=p['thinking_effort'])
  if p['temperature'] is not None:
    call._set_temperature(p['temperature'])
  if p['max_tokens'] is not None:
    call._set_max_tokens(p['max_tokens'])
  if images is not None:
    call._set_images(images)
  call._set_provider_kwargs(top_p=p['top_p'], top_k=p['top_k'])
  return call


def groq(model=None, reasoning_effort=None, temperature=None, max_tokens=None):
  model = model or catalog.DEFAULT_MODELS['groq']

  call = TextCall(provider='groq', model=model)
  if reasoning_effort is not None:
    call._set_thinking(effort=reasoning_effort)
  if temperature is not None:
    call._set_temperature(temperature)
  if max_tokens is not None:
    call._set_max_tokens(max_tokens)
  return call
