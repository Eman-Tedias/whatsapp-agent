import io
import logging
import warnings

from pathlib import Path
from langfuse import Langfuse, propagate_attributes
from PIL import Image

from .catalog import GUARDRAIL_MODELS, DEFAULT_MODELS, split_provider_model
from .prompts import GUARDRAIL_PROMPT, GUARDRAIL_SCHEMA
from . import config
from . import evaluation

_RETRY_ATTEMPTS = 3
_RETRY_BACKOFF_SECONDS = 1

# The library doesn't configure its own handler -- whoever consumes harpy decides
# if/how to display logs (level, format, destination). Without this, "No handlers
# found" or unexpected stderr output by logging's own default.
logger = logging.getLogger('harpy')
logger.addHandler(logging.NullHandler())


def _has_key(provider):
  if provider == 'gemini' and config.VERTEX_PROJECT:
    return True
  return bool({
    'openai': config.OPENAI_API_KEY,
    'gemini': config.GEMINI_API_KEY,
    'anthropic': config.ANTHROPIC_API_KEY,
    'groq': config.GROQ_API_KEY,
  }.get(provider))


_langfuse_client = None


def _get_langfuse_client():
  global _langfuse_client
  if _langfuse_client is not None:
    return _langfuse_client
  if not (config.LANGFUSE_ENABLED and config.LANGFUSE_PUBLIC_KEY and config.LANGFUSE_SECRET_KEY):
    return None
  _langfuse_client = Langfuse(
    public_key=config.LANGFUSE_PUBLIC_KEY,
    secret_key=config.LANGFUSE_SECRET_KEY,
    host=config.LANGFUSE_HOST,
  )
  return _langfuse_client


def _serialize_output(result):
  if hasattr(result, 'model_dump'):
    return result.model_dump()
  return result


class LLM:
  """Cross-cutting state + orchestration shared by TextCall (text.py) and ImageCall
  (image.py) -- prompts/context, guardrail, fallback, evaluate, tracing.

  Nothing here is provider-specific; whatever is (thinking, temperature, search,
  max_tokens, etc.) lives in text.py/image.py alongside whoever uses it.
  """

  def __init__(self, provider, model=None):
    self.provider = provider
    self._model = model
    self._system = None
    self._user = None
    self._context = {}
    self._fallbacks = []
    self._reasoning_tokens = None
    self._reasoning_effort = None
    self._include_thoughts = None
    self._guardrail_enabled = False
    self._guardrail_model = None
    self._guardrail_prompt = None
    self._input_images = []
    self._eval_enabled = False
    self._eval_config = None
    self._eval_judge_model = None
    self._temperature = None
    self._max_tokens = None
    self._provider_kwargs = {}
    self._trace_enabled = False
    self._trace_client = None
    self._trace_session_id = None
    self._trace_user_id = None
    self._trace_tags = None

  def guardrail(self, enabled=True, model=None, prompt=None):
    self._guardrail_enabled = enabled
    self._guardrail_model = model
    self._guardrail_prompt = prompt
    return self

  def trace(self, enabled=True, client=None, session_id=None, user_id=None, tags=None):
    self._trace_enabled = enabled
    self._trace_client = client
    self._trace_session_id = session_id
    self._trace_user_id = user_id
    self._trace_tags = tags
    return self

  def _set_temperature(self, value):
    self._temperature = value
    return self

  def _set_max_tokens(self, n):
    self._max_tokens = n
    return self

  def _set_provider_kwargs(self, **kwargs):
    # Internal plumbing used by the harpy.text/harpy.image factories -- names were
    # already validated there (param_rules.py) before reaching this point.
    self._provider_kwargs.update({k: v for k, v in kwargs.items() if v is not None})
    return self

  def evaluate(self, config=None, judge_model=None, enabled=True):
    from .schema import EvalConfig

    self._eval_enabled = enabled
    if config is not None:
      if isinstance(config, EvalConfig):
        self._eval_config = config
      else:
        import json
        with open(config, 'r', encoding='utf-8') as f:
          self._eval_config = EvalConfig.model_validate(json.load(f))
    if judge_model is not None:
      self._eval_judge_model = judge_model
    return self

  def prompts(self, system=None, user=None):
    if system is not None:
      self._system = system
    if user is not None:
      self._user = user
    return self

  def _set_images(self, sources=None):
    if sources is None:
      sources = []
    if isinstance(sources, list):
      self._input_images = sources
    else:
      self._input_images = [sources]
    return self

  def context(self, **kwargs):
    self._context.update(kwargs)
    return self

  def _interpolated_prompt(self):
    if not self._context:
      return self._user
    try:
      return self._user.format(**self._context)
    except KeyError as e:
      raise ValueError(
        f'Error building the prompt: key {e} was not found in .context(...). '
        f"If it's a literal key (not a placeholder to substitute), escape the braces "
        f"by doubling them -- '{{{{...}}}}' instead of '{{...}}'."
      ) from e

  def fallback(self, model=None):
    if model is None:
      hierarchy = ['gemini', 'anthropic', 'openai', 'groq']
      self._fallbacks = [p for p in hierarchy if p != self.provider and _has_key(p)]
    elif isinstance(model, list):
      self._fallbacks = model
    else:
      self._fallbacks = [model]
    return self

  def _set_thinking(self, reasoning_tokens=None, effort=None, include_thoughts=None):
    if reasoning_tokens is not None:
      self._reasoning_tokens = reasoning_tokens
    if effort is not None:
      self._reasoning_effort = effort
    if include_thoughts is not None:
      self._include_thoughts = include_thoughts
    return self

  def _score_guardrail(self, result):
    client = self._resolve_langfuse_client()
    if client is None:
      return
    client.score_current_trace(
      name='harpy.guardrail.allowed',
      value=float(result.allowed),
      data_type='BOOLEAN',
      comment=result.reason,
    )

  def _check_guardrail(self, text):
    if not self._guardrail_enabled:
      return
    from .text import TextCall

    user_prompt_template = self._guardrail_prompt or GUARDRAIL_PROMPT

    if self._guardrail_model is None:
      hierarchy = [self.provider] + [
        p for p in ('gemini', 'anthropic', 'openai', 'groq') if p != self.provider and _has_key(p)
      ]
      candidates = [(p, GUARDRAIL_MODELS[p]) for p in hierarchy]
    else:
      entries = self._guardrail_model if isinstance(self._guardrail_model, list) else [self._guardrail_model]
      candidates = [split_provider_model(entry, GUARDRAIL_MODELS) for entry in entries]

    def _run_guardrail_check():
      errors = []
      for provider, model in candidates:
        try:
          result = (
            TextCall(provider=provider, model=model)
            .trace(enabled=self._trace_enabled, client=self._trace_client)
            .prompts(user=user_prompt_template.format(text=text))
            .output(schema=GUARDRAIL_SCHEMA)
            ._run_body()
          )['response']
        except Exception as e:
          errors.append((provider, model, e))
          continue
        self._score_guardrail(result)
        if not result.allowed:
          raise ValueError(f'Guardrail blocked the input: {result.reason}')
        return
      # Every candidate's error, not just the last one -- if all of them raise the same
      # error, that's a sign of a code bug (affects every provider equally), not a single
      # provider being down (which would tend to error differently between them).
      details = '; '.join(f'{p}/{m}: {e}' for p, m, e in errors)
      raise RuntimeError(
        f'Guardrail is unavailable across every configured provider -- {details}'
      ) from errors[-1][2]

    self._traced_span(name='harpy.guardrail', fn=_run_guardrail_check, input_data=text)

  def _score_eval(self, eval_info, attempt, total_attempts):
    client = self._resolve_langfuse_client()
    if client is None:
      return
    comment = f'attempt {attempt + 1}/{total_attempts}'
    for criterion, value in eval_info['scores'].items():
      client.score_current_trace(name=f'harpy.eval.{criterion}', value=value, data_type='NUMERIC', comment=comment)
    client.score_current_trace(name='harpy.eval.passed', value=float(eval_info['passed']), data_type='BOOLEAN', comment=comment)

  def _run_eval_gate(self, result, regenerate, extract_content, content_type):
    if not self._eval_enabled:
      return result, None
    if self._eval_config is None:
      raise ValueError(
        "evaluate() was enabled without a config -- call evaluate(config='path.json') "
        "with your criteria and threshold before calling run()."
      )
    eval_config = self._eval_config
    judge_model_entry = self._eval_judge_model or eval_config.judge_model or evaluation_default_judge_model(content_type)
    judge_provider, judge_model = split_provider_model(judge_model_entry, DEFAULT_MODELS)

    if content_type == 'image' and not evaluation.judge_supports_images(judge_provider):
      warnings.warn(
        f"evaluate(): judge_model '{judge_model}' (provider '{judge_provider}') doesn't "
        f'support image evaluation -- skipping evaluation for this call.'
      )
      return result, None

    for attempt in range(evaluation.MAX_EVAL_ATTEMPTS):
      content = extract_content(result)
      if content_type == 'image':
        input_images = [content]
        content_text = '(see attached image)'
      else:
        input_images = []
        content_text = content

      from .schema import EvalList

      user_content = evaluation.build_user_content(
        criteria_text=evaluation.format_criteria(eval_config.criteria),
        obs_block=evaluation.format_obs(eval_config.obs),
        content_text=content_text,
      )
      messages = [{'role': 'user', 'content': user_content}]

      judge_result = self._traced_call(
        name='harpy.evaluate.judge',
        fn=lambda: evaluation.call_judge(
          provider=judge_provider, model=judge_model, messages=messages,
          output_model=EvalList, input_images=input_images,
        ),
        input_data=content_text,
        model=judge_model,
        metadata={
          'provider': judge_provider,
          'content_type': content_type,
          'attempt': attempt + 1,
          'thresholds': {name: c.threshold for name, c in eval_config.criteria.items()},
        },
        serialize_output=lambda r: serialize_judge_output(r, eval_config.criteria),
      )
      eval_info = serialize_judge_output(judge_result, eval_config.criteria)
      self._score_eval(eval_info, attempt, evaluation.MAX_EVAL_ATTEMPTS)

      logger.info(
        'attempt %d/%d (judge=%s) -- passed=%s',
        attempt + 1, evaluation.MAX_EVAL_ATTEMPTS, judge_model, eval_info['passed'],
      )

      if eval_info['passed'] or attempt == evaluation.MAX_EVAL_ATTEMPTS - 1:
        return result, eval_info
      result = regenerate(eval_info['feedback'])

  def _resolve_langfuse_client(self):
    if not self._trace_enabled:
      return None
    if self._trace_client is not None:
      return self._trace_client
    return _get_langfuse_client()

  def _traced_span(self, name, fn, input_data=None, metadata=None):
    langfuse_client = self._resolve_langfuse_client()
    if langfuse_client is None:
      return fn()

    with langfuse_client.start_as_current_observation(
      name=name,
      as_type='span',
      input=input_data,
      metadata=metadata or {},
    ) as span:
      try:
        result = fn()
        span.update(output=_serialize_output(result))
        return result
      except Exception as e:
        span.update(level='ERROR', status_message=str(e))
        raise

  def _traced_call(self, name, fn, input_data, model, metadata=None, serialize_output=_serialize_output):
    langfuse_client = self._resolve_langfuse_client()
    if langfuse_client is None:
      result, usage = fn()
      return result

    with langfuse_client.start_as_current_observation(
      name=name,
      as_type='generation',
      input=input_data,
      model=model,
      metadata=metadata or {},
    ) as generation:
      try:
        result, usage = fn()
        generation.update(output=serialize_output(result), usage_details=usage)
        return result
      except Exception as e:
        generation.update(level='ERROR', status_message=str(e))
        raise

  def _traced_run(self, name, fn, input_data=None, metadata=None):
    has_propagate_attrs = self._trace_enabled and (
      self._trace_session_id or self._trace_user_id or self._trace_tags
    )
    if not has_propagate_attrs:
      return self._traced_span(name=name, fn=fn, input_data=input_data, metadata=metadata)

    with propagate_attributes(
      session_id=self._trace_session_id,
      user_id=self._trace_user_id,
      tags=self._trace_tags,
    ):
      return self._traced_span(name=name, fn=fn, input_data=input_data, metadata=metadata)

  def _normalize_image(self, source):
    if isinstance(source, Image.Image):
      buffer = io.BytesIO()
      source.save(buffer, format=source.format or 'PNG')
      data = buffer.getvalue()
    elif isinstance(source, (str, Path)):
      data = Path(source).read_bytes()
    elif isinstance(source, bytes):
      data = source
    else:
      raise TypeError(f'Unsupported image source type: {type(source)}')
    if data[:5] == b'%PDF-':
      return data, 'application/pdf'
    image_format = Image.open(io.BytesIO(data)).format or 'PNG'
    return data, f'image/{image_format.lower()}'


def evaluation_default_judge_model(content_type):
  from .catalog import DEFAULT_JUDGE_MODELS
  return DEFAULT_JUDGE_MODELS[content_type]


def serialize_judge_output(judge_result, criteria):
  from .evaluation import score_items

  failed, passed = score_items(judge_result.items, criteria)
  scores = {item.criteria: item.grade for item in judge_result.items}
  per_criterion_passed = {item.criteria: item in passed for item in judge_result.items}
  aggregate = sum(scores.values()) / len(scores) if scores else 0.0
  feedback = _build_feedback(failed, passed)
  return {
    'scores': scores,
    'aggregate_score': aggregate,
    'thresholds': {name: c.threshold for name, c in criteria.items()},
    'per_criterion_passed': per_criterion_passed,
    'passed': not failed,
    'feedback': feedback,
  }


def _build_feedback(failed, passed):
  from .evaluation import build_feedback
  return build_feedback(failed, passed)
