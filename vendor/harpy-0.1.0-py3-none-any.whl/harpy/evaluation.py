from . import param_rules
from .prompts import EVAL_PROMPT

MAX_EVAL_ATTEMPTS = 3

# Fixed judge temperature -- high enough that scores don't collapse into identical
# values across criteria, regardless of which provider judges. This is harpy's own
# default, not something the caller chose, so it's skipped (see _call_judge) on
# model tiers that reject temperature rather than letting the API 400 because of an
# internal harpy setting.
JUDGE_TEMPERATURE = 1.0

RETRY_FEEDBACK_TEMPLATE = """

Your previous response was evaluated and did not meet the expected quality bar. Evaluator feedback:

{feedback}

Revise your response taking this feedback into account."""

# Providers whose provider.run() knows how to accept input_images -- used to decide
# whether a given judge model is able to evaluate image content at all.
IMAGE_CAPABLE_JUDGE_PROVIDERS = {'gemini', 'openai', 'anthropic'}


def judge_supports_images(provider: str) -> bool:
  return provider in IMAGE_CAPABLE_JUDGE_PROVIDERS


def format_criteria(criteria: dict) -> str:
  return '\n'.join(
    f'- {name} (type: {c.type}): {c.description}'
    for name, c in criteria.items()
  )


def format_obs(obs: str | None) -> str:
  if not obs:
    return ''
  return f'\n\nAdditional notes:\n{obs}'


def build_user_content(criteria_text: str, obs_block: str, content_text: str) -> str:
  return f'Criteria to Evaluate:\n{criteria_text}{obs_block}\n\nContent to Evaluate:\n{content_text}'


def score_items(items, criteria: dict):
  failed, passed = [], []
  for item in items:
    crit = criteria.get(item.criteria)
    threshold = crit.threshold if crit else 1.0
    (passed if item.grade >= threshold else failed).append(item)
  return failed, passed


def build_feedback(failed, passed) -> str:
  parts = []
  if failed:
    parts.append('Needs to be fixed:')
    parts += [f'- {item.criteria}: {item.reason}' for item in failed]
  if passed:
    parts.append("Already satisfactory on these -- keep the same level when regenerating:")
    parts += [f'- {item.criteria}: {item.reason}' for item in passed]
  return '\n'.join(parts)


def call_judge(provider, model, messages, output_model, input_images=None):
  # Local imports -- providers/*.py don't depend on evaluation.py, avoids a cycle.
  from .providers import openai, gemini, anthropic, groq

  input_images = input_images or []

  if provider == 'openai':
    temperature = None if param_rules.is_openai_reasoning_model(model) else JUDGE_TEMPERATURE
    return openai.run(
      model=model, messages=messages, output_model=output_model,
      system_prompt=EVAL_PROMPT, temperature=temperature, input_images=input_images,
    )
  if provider == 'gemini':
    return gemini.run(
      model=model, messages=messages, output_model=output_model,
      input_images=input_images, search_enabled=False, search_urls=None,
      system_prompt=EVAL_PROMPT, temperature=JUDGE_TEMPERATURE,
    )
  if provider == 'groq':
    return groq.run(
      model=model, messages=messages, output_model=output_model,
      system_prompt=EVAL_PROMPT, temperature=JUDGE_TEMPERATURE,
    )
  if provider != 'anthropic':
    # Without this, an invalid/typo'd provider (e.g. "gemeni/model") silently fell
    # through here and ran against Anthropic with the wrong model name -- a confusing
    # error from the wrong place instead of pointing at the actual typo.
    raise ValueError(
      f"Provider '{provider}' is invalid for judge_model -- use 'openai', 'gemini', "
      f"'anthropic' or 'groq'."
    )
  temperature = None if model in param_rules.ANTHROPIC_NO_TEMPERATURE else JUDGE_TEMPERATURE
  return anthropic.run(
    model=model, messages=messages, output_model=output_model, max_tokens=2048,
    system_prompt=EVAL_PROMPT, temperature=temperature, input_images=input_images,
  )
