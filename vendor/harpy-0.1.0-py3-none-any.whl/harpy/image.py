"""Entry point namespace for image generation: harpy.image.<provider>(model=..., ...).

Only Gemini generates images today.

ImageCall lives here (not in core.py) -- it's the state + image-specific setters
(_set_image_config(), etc.), only reachable through the factory below. core.py only
has what's shared with TextCall (LLM).
"""

import io
import time

from PIL import Image, UnidentifiedImageError

from . import catalog
from . import param_rules
from . import evaluation
from .core import LLM, _RETRY_ATTEMPTS, _RETRY_BACKOFF_SECONDS
from .providers import gemini as gemini_provider


def _resolve_image_fallback(entry):
  """Validate and extract the model name from an image fallback entry.

  Accepts "model" or "gemini/model" (same syntax as text fallback) -- only Gemini
  generates images today, so any other provider prefix is invalid. The prefix used
  to be silently discarded (`.split("/", 1)[1]`), so "openai/x" turned into "x" and
  was sent to the Gemini API with no warning at all.
  """
  if '/' in entry:
    provider, model = entry.split('/', 1)
    if provider != 'gemini':
      raise ValueError(
        f"ImageCall.fallback(): provider '{provider}' is invalid -- only Gemini "
        f"generates images today. Use 'gemini/{model}' or just '{model}'."
      )
    return model
  return entry


class ImageCall(LLM):

  def __init__(self, provider, model=None):
    super().__init__(provider, model)
    self._aspect_ratio = '1:1'
    self._image_size = '1K'
    self._return_image = False

  def fallback(self, model=None):
    if model is None:
      # No automatic cascade -- only Gemini generates images today, so there's no
      # sensible "other provider" to fall back to. Fail loud instead of a silent no-op.
      raise ValueError(
        "ImageCall.fallback() needs an explicit model= -- there is no automatic "
        'cascade of image models (only Gemini generates images today). Pass '
        "fallback(model='other-model') or fallback(model=['model-a', 'model-b'])."
      )
    elif isinstance(model, list):
      self._fallbacks = model
    else:
      self._fallbacks = [model]
    return self

  def _set_image_config(self, aspect_ratio=None, image_size=None):
    if aspect_ratio is not None:
      self._aspect_ratio = aspect_ratio
    if image_size is not None:
      self._image_size = image_size
    return self

  def return_image(self, return_image):
    self._return_image = return_image
    return self

  def _run_with_fallbacks(self, prompt, model, input_images, fallbacks):
    # Pulled out here because they're read twice (retry block + fallback block) --
    # same convention as TextCall._run_with_fallbacks (which already receives
    # everything via parameters).
    aspect_ratio = self._aspect_ratio
    image_size = self._image_size
    system_prompt = self._system
    effort = self._reasoning_effort
    reasoning_tokens = self._reasoning_tokens
    temperature = self._temperature
    include_thoughts = self._include_thoughts
    max_tokens = self._max_tokens

    last_error = None
    for attempt in range(_RETRY_ATTEMPTS):
      try:
        return self._traced_call(
          name=f'harpy.call ({self.provider})',
          fn=lambda: gemini_provider.run_image(
            model=model, prompt=prompt, input_images=input_images,
            aspect_ratio=aspect_ratio, image_size=image_size, system_prompt=system_prompt,
            effort=effort, reasoning_tokens=reasoning_tokens, temperature=temperature,
            include_thoughts=include_thoughts, max_tokens=max_tokens,
          ),
          input_data=prompt, model=model,
          metadata={'provider': self.provider, 'attempt': attempt + 1},
          serialize_output=lambda r: {'bytes': len(r)},
        )
      except Exception as e:
        last_error = e
        if attempt < _RETRY_ATTEMPTS - 1:
          time.sleep(_RETRY_BACKOFF_SECONDS * (2 ** attempt))

    for fallback in fallbacks:
      fb_model = _resolve_image_fallback(fallback)
      try:
        return self._traced_call(
          name=f'harpy.fallback ({self.provider})',
          fn=lambda: gemini_provider.run_image(
            model=fb_model, prompt=prompt, input_images=input_images,
            aspect_ratio=aspect_ratio, image_size=image_size, system_prompt=system_prompt,
            effort=effort, reasoning_tokens=reasoning_tokens, temperature=temperature,
            include_thoughts=include_thoughts, max_tokens=max_tokens,
          ),
          input_data=prompt, model=fb_model,
          metadata={'provider': self.provider, 'fallback': True},
          serialize_output=lambda r: {'bytes': len(r)},
        )
      except Exception as e:
        last_error = e
        continue
    raise last_error

  def _run_body(self):
    provider = self.provider
    model = self._model or catalog.DEFAULT_IMAGE_MODELS[provider]
    input_images = [self._normalize_image(source=s) for s in self._input_images]
    # Extract the model before comparing -- "gemini/<model>" and "<model>" are the same
    # fallback, but comparing raw strings misses that (a fallback identical to the
    # primary model used to slip past dedup and run again, wasting a redundant attempt).
    fallbacks = [m for m in self._fallbacks if _resolve_image_fallback(m) != model]
    prompt = self._interpolated_prompt()
    self._check_guardrail(prompt)

    def _generate(current_prompt):
      return self._run_with_fallbacks(current_prompt, model, input_images, fallbacks)

    response = _generate(prompt)
    eval_info = None

    if self._eval_enabled:
      response, eval_info = self._run_eval_gate(
        result=response,
        regenerate=lambda feedback: _generate(prompt + evaluation.RETRY_FEEDBACK_TEMPLATE.format(feedback=feedback)),
        extract_content=self._normalize_image,
        content_type='image',
      )

    if self._return_image:
      try:
        response = Image.open(io.BytesIO(response))
      except UnidentifiedImageError as e:
        raise ValueError('Gemini did not return a valid image.') from e

    output = {'response': response}
    if self._eval_enabled:
      output['eval'] = eval_info
    return output

  def run(self):
    return self._traced_run(
      name='harpy.run',
      fn=self._run_body,
      input_data=self._interpolated_prompt(),
      metadata={'provider': self.provider},
    )['response']


def gemini(model=None, aspect_ratio=None, image_size=None, thinking_budget=None,
           thinking_level=None, include_thoughts=None, temperature=None, images=None,
           max_tokens=None):
  model = model or catalog.DEFAULT_IMAGE_MODELS['gemini']
  p = param_rules.check_gemini_params(model, thinking_budget=thinking_budget, thinking_level=thinking_level,
                                       max_tokens=max_tokens)

  call = ImageCall(provider='gemini', model=model)
  if aspect_ratio is not None or image_size is not None:
    call._set_image_config(aspect_ratio=aspect_ratio, image_size=image_size)
  if p['thinking_budget'] is not None or p['thinking_level'] is not None or include_thoughts is not None:
    call._set_thinking(reasoning_tokens=p['thinking_budget'], effort=p['thinking_level'], include_thoughts=include_thoughts)
  if temperature is not None:
    call._set_temperature(temperature)
  if images is not None:
    call._set_images(images)
  if p['max_tokens'] is not None:
    call._set_max_tokens(p['max_tokens'])
  return call
