class ProviderParameterError(ValueError):
  """A parameter is fundamentally incompatible with a model (not just droppable).

  Subclasses ValueError so existing `except ValueError`/`except Exception` handlers
  keep working, while callers who want to distinguish "invalid parameter combo" from
  "the API call itself failed" can catch this specifically.
  """

  def __init__(self, provider, model, param, reason=None):
    self.provider = provider
    self.model = model
    self.param = param
    message = f"Parameter '{param}' is not supported by model '{model}' ({provider})."
    if reason:
      message += f' {reason}'
    super().__init__(message)
