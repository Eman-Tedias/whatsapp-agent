"""Model/provider resolution: defaults and 'provider/model' parsing.

Per-provider parameter validation (what each API accepts or rejects) lives in
param_rules.py -- a different axis (grows with model *capability*, not model
name/default) that evolves at its own pace.

There is deliberately no whitelist of "valid" model names here anymore: a fixed list
goes stale on every new model release, and the provider API itself is the source of
truth for whether a model name exists. Passing garbage as a model name is caught by
the provider API returning an error, not by harpy pre-validating it.
"""

DEFAULT_MODELS = {
  'openai': 'gpt-4o-mini',
  'gemini': 'gemini-2.5-flash',
  'anthropic': 'claude-haiku-4-5',
  'groq': 'llama-3.1-8b-instant',
}

DEFAULT_IMAGE_MODELS = {
  # 'gemini-3-pro-image-preview' was retired -- 'gemini-3-pro-image' (no "-preview")
  # is the GA replacement (ai.google.dev/gemini-api/docs/deprecations).
  'gemini': 'gemini-3-pro-image',
}

GUARDRAIL_MODELS = {
  'openai': 'gpt-5.4-nano',
  'gemini': 'gemini-2.5-flash-lite',
  'anthropic': 'claude-haiku-4-5',
  'groq': 'llama-3.1-8b-instant',
}

# Default judge model per evaluated content type -- 'provider/model' format (see
# split_provider_model). Image judging requires a multimodal judge -- only gemini
# supports input_images today (see evaluation.IMAGE_CAPABLE_JUDGE_PROVIDERS).
DEFAULT_JUDGE_MODELS = {
  'text': 'gemini/gemini-3.5-flash',
  'image': 'gemini/gemini-3.5-flash',
}

MODEL_OVERRIDES = {
  'gemini-3.5-flash': {'temperature': 1},
}


def resolve_temperature(model: str, temperature):
  return MODEL_OVERRIDES.get(model, {}).get('temperature', temperature)


def split_provider_model(entry: str, default_models: dict) -> tuple[str, str]:
  """Resolve a fallback/judge_model entry in 'provider/model' format.

  Without a "/" in the entry, treats it as a bare provider name and uses its default
  (e.g. "openai" -> ("openai", DEFAULT_MODELS["openai"])). None of the providers use
  "/" in an actual model name, so the parse is unambiguous.

  A bare model name (no "/", and not a valid provider) is no longer resolved by
  scanning model lists (that mechanism was intentionally removed -- it goes stale on
  every new release). Instead of a raw KeyError, this fails with a message that
  explains the required format.
  """
  if '/' in entry:
    provider, model = entry.split('/', 1)
    return provider, model
  if entry not in default_models:
    raise ValueError(
      f"'{entry}' is not a valid provider ({'/'.join(default_models)}) nor in "
      f"'provider/model' format -- harpy requires an explicit provider for bare model "
      f"names. Example: '{next(iter(default_models))}/{entry}'."
    )
  return entry, default_models[entry]
